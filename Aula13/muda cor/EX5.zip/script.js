function mudarCor() {
  const div = document.getElementById("quadrado");
  div.style["background-color"] = "red";
}

function voltarCor(){
  const div = document.getElementById("quadrado");
  div.style["background-color"] = "gray";
}